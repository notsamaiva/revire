# Security Policy


## Reporting a Vulnerability

For responsible disclosure of security concerns, see our program page at https://hackerone.com/revive_adserver
